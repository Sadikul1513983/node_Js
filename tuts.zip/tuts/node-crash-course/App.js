const express=require('express');
//express app
const app=express()


 app.set('view engine','ejs');
app.listen(3000);


app.get('/',(req,res)=>{
    const blogs=[
        {title: 'yoshi finds eggs', snippets: 'lorem ipsum dolor sit amet'}
        {title: 'mario finds eggs', snippets: 'lorem ipsum dolor sit amet'}
        {title: 'yogesh finds eggs', snippets: 'lorem ipsum dolor sit amet'}
        {title: 'howo finds eggs', snippets: 'lorem ipsum dolor sit amet'}
        {title: 'hoewl finds eggs', snippets: 'lorem ipsum dolor sit amet'}
    ];
    res.render('index',{title : 'home',blogs});
})







app.get('/' , (req,res)=>{
    req.send('<p> home page</p>');
    res.sendFile('./views/index.html', {root:__dirname});
})
app.get('/about' , (req,res)=>{
    req.send('<p> about page</p>');
    res.sendFile('./views/about.html', {root:__dirname});
})
app.get('/about',(req,res)=>{
    req.redirect('/about')
})
app.use((req,res)=>{
    res.sendFile('./views/404.html', {root:__dirname});
})
app.get('/about' , (req,res)=>{
    res.sendFile('./views/about.html', {root:__dirname});
})