
const people=['yoshi','ryu','chun','mario'];
const age=[20,30,40,50]
console.log(people)

module.export=people{
    people,age
}